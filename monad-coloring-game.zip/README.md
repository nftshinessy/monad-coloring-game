# Monad Coloring Game

A fun coloring game built for the Monad blockchain community.

## Features

- Connect your Web3 wallet
- Color the Monad logo as fast as you can
- Compete on the global leaderboard
- Share your results on Twitter

## Installation

1. Clone the repository:
```bash
git clone https://github.com/nftshinessy/monad-coloring-game.git
cd monad-coloring-game